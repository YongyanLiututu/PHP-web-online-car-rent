<?php
//use PHPMailer;

require 'D:\31748Assignment2\Assignment5.25\PHPMailer.php';
require 'D:\31748Assignment2\Assignment5.25\SMTP.php';
require 'D:\31748Assignment2\Assignment5.25\Exception.php';
session_start();
$mail = new PHPMailer\PHPMailer\PHPMailer();
if (isset($_POST['name'])) {
    $name = $_POST['name'];
} else {

    header('Location: ./index.php');
}

if (isset($_POST['address'])) {
    $address = $_POST['address'];
} else {

    header('Location: ./index.php');
}
if (isset($_POST['phone'])) {
    $phone = $_POST['phone'];
} else {

    header('Location: ./index.php');
}

if (isset($_POST['email'])) {
    $email = $_POST['email'];
} else {

    header('Location: ./index.php');
}

if (isset($_POST['suburb'])) {
    $suburb = $_POST['suburb'];
} else {

    header('Location: ./index.php');
}
if (isset($_POST['state'])) {
    $state = $_POST['state'];
} else {

    header('Location: ./index.php');
}
if (isset($_POST['country'])) {
    $country = $_POST['country'];
} else {

    header('Location: ./index.php');
}
//use PHPMailer\PHPMailer\PHPMailer();
//error_reporting(E_ALL);
//ini_set('display_errors', 1);
// 创建一个 PHPMailer 实例
if (!class_exists('PHPMailer\PHPMailer\PHPMailer')) {

    echo 'PHPMailer class is not loaded';
    exit;
}

// 创建 PHPMailer 对象，并进一步设置和发送邮件
//$mail = new PHPMailer\PHPMailer\PHPMailer();


//// 获取用户输入
//$name = $_POST['name'];
//$email = $_POST['email'];
//$order = $_POST['order'];



$mail->isSMTP();
$mail->Host = 'smtp.qq.com';
$mail->Port = 465;

$mail->SMTPSecure = 'ssl';



$mail->SMTPAuth = true;


$mail->Username = '1109552635@qq.com';
$mail->Password = 'qbkvkzuvamiyjjfe';

$mail->setFrom('1109552635@qq.com', 'yongyan liu');
$mail->addAddress("$email", "$name");

function cost($cart)
{
    $total_cost = 0;
    foreach ($cart as $item) {

        $item_cost = $item['price_per_day'] * $item['days'];
        $total_cost += $item_cost;
    }
    return $total_cost;
}

$cartItems = isset($_SESSION['cars']) ? $_SESSION['cars'] : [];



$mail->Subject = 'Order Confirmation';
$mail->Body = 'Hi! Dear ' . $name . "\r\n" .
    'Thank you for placing an order in our uts online store!!!' . "\r\n" .
    'Our store pursues 100% high-quality products and hopes to get your satisfactory feedback!!' . "\r\n" .
//    '-----------------------------' . "\r\n";
$mail->Body .= '-----------------------------' . "\r\n" .


    'Phone: ' . $phone . "\r\n" .
    'Email: ' . $email . "\r\n" .
    'Suburb: ' . $suburb . "\r\n" .
    'State: ' . $state . "\r\n" .
    'Country: ' . $country . "\r\n" .
    'Address: ' . $address . "\r\n" .
    '-----------------------------------' . "\r\n";
    '-----------------------------------' . "\r\n";

foreach ($cartItems as $item) {
    $category = $item['category'];
    $brand = $item['brand'];
    $model = $item['model'];
    $year = $item['year'];
    $price_per_day = $item['price_per_day'];
    $days= 1;

    $itemCost = $price_per_day * $days;
    $mail->Body .= 'category: ' . category . "\r\n" .
        'brand: ' . $brand . "\r\n" .
        'model: ' . $model . "\r\n" .
        'year: ' . $year . "\r\n" .
        'price_per_day: ' . $price_per_day . "\r\n" .
        'Item Cost: $' . $itemCost . "\r\n" .
        '-----------------------------------' . "\r\n";
}

$total_cost = cost($_SESSION['cart']);
echo 'Total Cost: ' . $total_cost;
$mail->Body .= 'Total Cost: $' . $total_cost . "\r\n";



if(!$mail->send()) {
    echo 'Fail!';
    echo 'Error message：' . $mail->ErrorInfo;
//    header('Location: ./thankyouPage.php');
} else {
    echo 'success！';
    echo $cartItems;
    header('Location: ./thankyouPage.php');

}


?>
