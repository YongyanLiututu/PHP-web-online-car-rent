<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $cartData = json_decode(file_get_contents('php://input'), true);

    // 更新JSON文件中的日期
    $filename = 'cart_data.json';
    $jsonData = file_get_contents($filename);
    $cartItems = json_decode($jsonData, true);
    

    foreach ($cartItems as &$item) {
        foreach ($cartData as $updatedItem) {
            echo '-----------------------------------';
            echo $item['itemId'];
            echo $updatedItem['id'];
            if ($item['itemId'] == $updatedItem['id']) {
                $item['days'] = $updatedItem['days'];
                $item['subtotal'] = $updatedItem['subtotal'];
                // 进行其他更新操作，根据需要进行修改
            }
        }
    }

    // 将更新后的数据写入JSON文件
    file_put_contents($filename, json_encode($cartItems));

    // 返回成功的响应
    header('Content-Type: application/json');
    echo json_encode(['status' => 'success']);
}




//session_start();
//
//if ($_SERVER['REQUEST_METHOD'] == 'POST') {
//    // 从客户端接收要更新的商品ID和天数
//    $requestData = json_decode(file_get_contents('php://input'), true);
//    $itemId = $requestData['itemId'];
//    $days = $requestData['days'];
//
//    // 在购物车中查找对应的商品并更新天数字段
//    if (isset($_SESSION['cart'])) {
//        foreach ($_SESSION['cart'] as &$item) {
//            if ($item['id'] == $itemId) {
//                $item['days'] = $days;
//                break;
//            }
//        }
//    }
//
//    // 将更新后的购物车内容保存到文件中
//    saveCartToFile($_SESSION['cart']);
//
//    // 返回成功的响应
//    header('Content-Type: application/json');
//    echo json_encode(['status' => 'success']);
//}
//
//function saveCartToFile($cart) {
//    // 将购物车内容保存到文件中
//    $filename = 'cart_data.json';
//    file_put_contents($filename, json_encode($cart));
//}
