
<!DOCTYPE html>
<html>
<head>
    <title>Car Rental System</title>
    <link rel="stylesheet" href="style.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

</head>
<body>
<header class="header">
    <div class="logo">
        <img src="logo.png" alt="Logo">
    </div>
    <div class="header1">
        <h1>Hertz-UTS</h1>
    </div>
    <ul class="ul-shop">

        <li><a href="#" id="searchBtn" onclick="function jumpToCartPage2() {
    window.location.href = './list_carrt.php';} jumpToCartPage2()">Home</a></li>

    </ul>
</header>
</body>

<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');

session_start();

function customErrorHandler($errno, $errstr, $errfile, $errline) {
    // 处理错误信息
}

set_error_handler('customErrorHandler');
// 检查是否有提交的表单数据

//// 更新购物车中的租赁天数
//foreach ($_SESSION['cart'] as &$itemextracted) {
//    $id = $itemextracted['id'];
//    $daysrentedday = 1;
//    if ($daysrentedday > 0) {
//        $itemextracted['days'] = $daysrentedday;
//    } else {
//        $itemextracted['days'] = 10;
//    }
//}



if (isset($_POST['remove'])) {
    // 从购物车中删除选定的项目
    $id = intval($_POST['remove']);
    unset($_SESSION['cart'][$id]);
}

?>
<!---->
<!--<div>================================================================</div>-->
<?php
if (!empty($_SESSION['cart'])) {
    // 计算购物车中所有项目的总价格
    $total_price = 0;
    foreach ($_SESSION['cart'] as $itemextracted) {
        $total_price += $itemextracted['price'] * $itemextracted['days'];
    }


    // 输出购物车表单

    echo '<input type="hidden" name="session_id" value="' . session_id() . '">';
    ?>

    <?php

    echo '<table class="shop-cart">';
    ?>
    <?php
    echo '<tr><th>Car Picture</th><th>Car Info</th><th>Price/Day</th><th>Rental Days</th><th>Subtotal</th><th>Actions</th></tr>';

    $cartItems = json_decode(file_get_contents('cart_data.json'), true);

// 遍历购物车内容并输出每个项目的信息和操作
    foreach ($cartItems as $itemextracted) {
        // 计算每个项目的小计
        echo "-----------------";
        echo '<div class="top">';
        // var_dump($itemextracted);
        echo '</div>';
        $subtotal = $itemextracted['price'] * $itemextracted['days'];
        // 输出每个项目的信息和操作
        echo '<tr>';
        echo '<td ><img class="shop-img" src="./photo/' . $itemextracted['id'] . '.png"></td>';
        echo '<td class="shop-td">' . $itemextracted['brand'] . ' ' . $itemextracted['model'] . ' (' . $itemextracted['year'] . ')</td>';
        echo '<td class="shop-td"    name="price-' . $itemextracted['id'] . '">$' . $itemextracted['price'] . '</td>';
//        echo '<td class="shop-td">';
        echo '<td class="shop-td"><input type="number" name="days-' . $itemextracted['id'] . '" value="' . $itemextracted['days'] . '" min="10"></td>';

//        echo '</td>';
        echo '<td class="shop-td" id="subtotal-' . $itemextracted['id'] . '">$' . $subtotal . '</td>';
        echo '<td class="shop-td"><a href="remove_from_cart.php?itemId=' . $itemextracted['id'] . '">Remove</a></td>';
        echo '</tr>';
    }




    // 输出购物车总价和更新按钮  <button type="submit">Empty the cart</button>
    echo '<tr><td colspan="3" ><strong>Total:</strong></td><td><strong id="total-price">$' . $total_price . '</strong></td><td><button  name="checkout" onclick="checkout1()">checkout</button></td><td><button  name="checkout" onclick="checkout1()">checkout</button></td>
<td><button  name="update" onclick="updateCart()">Refresh</button></td></tr>';
    echo '</table>';

} else {
    // 如果购物车为空，则显示一个消息
    echo '<div class="shop-p">';
    echo '<p>';
echo 'Your cart for your reserved vehicle is empty, please return to the main page to select your preferred vehicle!';
    echo '<li class="li-shop"><a class="shop-a" href="./list_carrt.php">Home</a></li>';

    echo '<script>
        setTimeout(function() {

            window.location.href = "./list_carrt.php";
        }, 5000);
      </script>';
echo '<p class="shop-p2"> It will go to the main page in 5 seconds............</p>';
    echo '</div>';


}










echo '<script>
function checkout1() {
    // 检查购物车是否为空
    if (' . count($_SESSION['cart']) . ' == 0) {
        alert("No car has been reserved.");
        window.location.href = "index.php";
        return;
    }
    // 获取所有“租赁天数”输入字段
    var daysFields = document.querySelectorAll(\'input[name^="days-"]\');
    // 验证每个“租赁天数”输入字段的值
    for (var i = 0; i < daysFields.length; i++) {
        var days = parseInt(daysFields[i].value);
        if (isNaN(days) || days <= 0) {
            alert("Rental days must be an integer greater than zero.");
            daysFields[i].focus();
            return;
        }
    }
    // 跳转到结算页面
    window.location.href = "checkout.php";
}



</script>';
echo '<script>
function checkout1() {
    // 检查购物车是否为空
    if (' . count($_SESSION['cart']) . ' == 0) {
        alert("No car has been reserved.");
        window.location.href = "index.php";
        return;
    }
    // 获取所有“租赁天数”输入字段
    var daysFields = document.querySelectorAll(\'input[name^="days-"]\');
//     console.log(daysFields);
    // 验证每个“租赁天数”输入字段的值
    for (var i = 0; i < daysFields.length; i++) {
        var days = parseInt(daysFields[i].value);
        if (isNaN(days) || days <= 0) {
            alert("Rental days must be an integer greater than zero.");
            daysFields[i].focus();
            return;
        }
    }
    // 跳转到结算页面
    window.location.href = "emailaddress.php";
//    window.location.href = "checkout.php";
}

</script>';

    $cartItems = json_decode(file_get_contents('cart_data.json'), true);
     $jsonData = json_encode($cartItems);

    
echo '<script>




 function updateCart() {
         var daysInputs = document.querySelectorAll(\'input[name^="days-"]\');
        console.log(daysInputs);
          var total_price = 0;
          var cartData = [];
           daysInputs.forEach(function(input){
            var itemId = input.name.split(\'-\')[1];
            var days = input.value;
            var price =  getprice(itemId);
            var subtotal = price * days;
          var subtotalElement = document.getElementById(\'subtotal-\' + itemId);
            if (subtotalElement) {
       subtotalElement.textContent = \'$\' + subtotal.toFixed(2);
        total_price += subtotal;
       
       console.log("yyyyyyyyyyyyyyyyyyyyyyyyyyyy");
       console.log(total_price);
        var itemData = {
               itemId: itemId,
                days: days,
               subtotal: subtotal
           };
           cartData.push(itemData);
  
   }; 

           });
          
    var totalPriceElement = document.getElementById(\'total-price\');
if (totalPriceElement) {
   totalPriceElement.innerHTML = \'$\' + total_price.toFixed(2);
}
          
           var xhr = new XMLHttpRequest();
       xhr.onreadystatechange = function() {
          if (xhr.readyState === 4 && xhr.status === 200) {
               // 更新请求成功
           }
      };
       xhr.open(\'POST\', \'update.php\');
       xhr.setRequestHeader(\'Content-Type\', \'application/json\');
       xhr.send(JSON.stringify(cartData));
   }
  
   var cartData = ' . $jsonData .';

  function getprice(id) {
//      console.log("cartData:", cartData);
//      console.log(cartData.length);
      for (var i = 0; i < cartData.length; i++) {
            if (cartData[i].id === id) {
//                console.log(cartData[i].price);
                return cartData[i].price;
                
            }
        }
//        return null; // 如果未找到匹配的 ID，则返回 null 或其他适当的默认值
//    }
      
      
           return 1000;
 }

   
   
   

//        var cartData = [];
//
//        daysInputs.forEach(function(input) ){
//            var itemId = input.name.split(\'-\')[1];
//            var days = input.value;
//
//            // 计算小计金额
//            var price = parseFloat(input.dataset.price);
//            var subtotal = price * days;
//
//            // 更新小计金额显示
//            var subtotalElement = document.getElementById(\'subtotal-\' + itemId);
//            subtotalElement.textContent = \'$\' + subtotal.toFixed(2);
//
//            // 更新JSON数据
//            var itemData = {
//                itemId: itemId,
//                days: days,
//                subtotal: subtotal
//            };
//            cartData.push(itemData);
//        });
//
//        // 发送更新请求到服务器
//        var xhr = new XMLHttpRequest();
//        xhr.onreadystatechange = function() {
//            if (xhr.readyState === 4 && xhr.status === 200) {
//                // 更新请求成功
//            }
//        };
//        xhr.open(\'POST\', \'update.php\');
//        xhr.setRequestHeader(\'Content-Type\', \'application/json\');
//        xhr.send(JSON.stringify(cartData));
//    }
</script>';

?>

<script>


     // function updateCart() {
     //     var daysInputs = document.querySelectorAll('input[name^="days-"]');
     //     console.log(daysInputs);
     //     var cartData = [];
     //
     //     daysInputs.forEach(function(input) {
     //         var itemId = input.name.split('-')[1];
     //         var days = input.value;
     //
     //         // 计算小计金额
     //         var price = 70;
     //         var subtotal = price * days;
     //
     //         // 更新小计金额显示
     //         var subtotalElement = document.getElementById('subtotal-' + itemId);
     //         subtotalElement.textContent = '$' + subtotal.toFixed(2);
     //
     //         // 更新JSON数据
     //         var itemData = {
     //             itemId: itemId,
     //             days: days,
     //             subtotal: subtotal
     //         };
     //         cartData.push(itemData);
     //     });
     //
     //     // 发送更新请求到服务器
     //     var xhr = new XMLHttpRequest();
     //     xhr.onreadystatechange = function() {
     //         if (xhr.readyState === 4 && xhr.status === 200) {
     //             // 更新请求成功
     //         }
     //     };
     //     xhr.open('POST', 'update.php');
     //     xhr.setRequestHeader('Content-Type', 'application/json');
     //     xhr.send(JSON.stringify(cartData));
     // }


    function removeFromCart(itemId) {
        // 构造请求
        var request = new XMLHttpRequest();
        request.open('POST', 'remove_from_cart.php', true);
        request.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8');

        // 处理响应
        request.onload = function() {
            if (request.status >= 200 && request.status < 400) {
                // 从购物车表格中删除对应的行
                var rowToRemove = document.getElementById('item-' + itemId);
                rowToRemove.parentNode.removeChild(rowToRemove);
            }
        };

        // 发送请求
        request.send('itemId=' + encodeURIComponent(itemId));
    }

    function checkout1() {
        // 检查购物车是否为空
        if (<?php echo count($_SESSION['cart']); ?> == 0) {
            alert("No car has been reserved.");
            window.location.href = "index.php";
            return;
        }
        // 获取所有“租赁天数”输入字段
        var daysFields = document.querySelectorAll('input[name^="days-"]');
        // 验证每个“租赁天数”输入字段的值
        for (var i = 0; i < daysFields.length; i++) {
            var days = parseInt(daysFields[i].value);
            if (isNaN(days) || days <= 0) {
                alert("Rental days must be an integer greater than zero.");
                daysFields[i].focus();
                return;
            }
        }
        // 跳转到结算页面
        window.location.href = "emailaddress.php";
        // window.location.href = "checkout.php";
    }

    function validateDays(field) {
        var days = parseInt(field.value);
        if (isNaN(days) || days <= 0) {
            alert("Rental days must be an integer greater than zero.");
            field.focus();
        }
    }



     //
     //     function getprice(id) {
     //         return 1000;
     //     // 在 cartData 中搜索对应的 ID，并返回价格
     // //     for (var i = 0; i < cartData.length; i++) {
     // //     if (cartData[i].id === id) {
     // //     return cartData[i].price;
     // // }
     // // }
     // //     return null; // 如果未找到匹配的 ID，则返回 null 或其他适当的默认值
     // }

         // 示例用法
     //     var id = 123; // 要搜索的 ID
     //     var price = getPrice(id);
     //     if (price !== null) {
     //     console.log("Price for ID " + id + ": " + price);
     // } else {
     //     console.log("Price not found for ID " + id);
     // }

     // $cartItems = json_decode($jsonData, true);
     // function getprice(id){
     //     $cartItems = json_decode(file_get_contents('cart-data.json'), true);
     //     return 40;
     // }

     </scrip>