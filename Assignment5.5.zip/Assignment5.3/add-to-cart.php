<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // 从客户端接收添加到购物车的商品信息
    $addedtoshoppingcartItem = json_decode(file_get_contents('php://input'), true);
//    $_SESSION['cart']=array();
    // 将商品信息添加到购物车中
    $_SESSION['cart'][] = $addedtoshoppingcartItem;

//    error_log('Added item to cart: ' . var_export($addedtoshoppingcartItem, true));
//
//    echo 1;
    // A successful response is returned
    header('Content-Type: application/json');

    echo json_encode(['status' => 'success']);

} else if ($_SERVER['REQUEST_METHOD'] == 'GET') {
// Get all item information from the shopping cart
    $cartItems = isset($_SESSION['cart']) ? $_SESSION['cart'] : [];

    // Returns the JSON format of all product information
    header('Content-Type: application/json');
    echo json_encode($cartItems);
}
?>
