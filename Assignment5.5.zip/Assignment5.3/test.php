<form method="post" action="clear_cart.php">
    <input type="hidden" name="session_id" value="<?php echo session_id(); ?>">
    <button type="submit">Empty the cart</button>
</form>
<table>
    <tr>
        <th>Car Info</th>
        <th>Price/Day</th>
        <th>Rental Days</th>
        <th>Subtotal</th>
        <th>Actions</th>
    </tr>
    <?php foreach ($_SESSION['cart'] as $item) {
        // 计算每个项目的小计
        $subtotal = $item['price'] * $item['days'];
        // 输出每个项目的信息和操作
        echo '<tr>';
        echo '<td>' . $item['brand'] . ' ' . $item['model'] . ' (' . $item['year'] . ')</td>';
        echo '<td>$' . $item['price'] . '</td>';
        echo '<td><input type="number" name="days-' . $item['id'] . '" value="' . $item['days'] . '" min="1" onblur="validateDays(this)"></td>';
        echo '<td>$' . $subtotal . '</td>';
        echo '<td><button type="submit" name="remove_item" value="' . $item['id'] . '">Remove</button></td>';
        echo '</tr>';
    } ?>
</table>

<button type="button" onclick="checkout()">Checkout</button>

<script>
    function checkout() {
        // 检查购物车是否为空
        if (<?php echo count($_SESSION['cart']); ?> == 0) {
            alert("No car has been reserved.");
            window.location.href = "index.php";
            return;
        }
        // 获取所有“租赁天数”输入字段
        var daysFields = document.querySelectorAll('input[name^="days-"]');
        // 验证每个“租赁天数”输入字段的值
        for (var i = 0; i < daysFields.length; i++) {
            var days = parseInt(daysFields[i].value);
            if (isNaN(days) || days <= 0) {
                alert("Rental days must be an integer greater than zero.");
                daysFields[i].focus();
                return;
            }
        }
        // 跳转到结算页面
        window.location.href = "checkout.php";
    }

    function validateDays(field) {
        var days = parseInt(field.value);
        if (isNaN(days) || days <= 0) {
            alert("Rental days must be an integer greater than zero.");
            field.focus();
        }
    }
</script>
