<form id="order-form" method="post" action="submit_order.php">
    <input type="text" name="name" placeholder="name" required>
    <input type="email" name="email" placeholder="email" required>
    <input type="tel" name="phone" placeholder="phone" required>
    <textarea name="address" placeholder="address·" required></textarea>
    <input type="tel" name="country" placeholder="country" required>
    <input type="tel" name="state" placeholder="state" required>
    <input type="tel" name="suburb" placeholder="suburb" required>
    <button type="submit" onclick="redirectToOrderConfirmation()">提交order</button>
</form>

<script>
    function redirectToOrderConfirmation() {
        // 使用JavaScript submit()方法提交表单
        document.getElementById('order-form').submit();

        // window.location.href = "./order_confirmation.php";
    }
</script>
