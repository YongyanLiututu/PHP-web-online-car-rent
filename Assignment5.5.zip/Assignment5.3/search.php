<?php
// 获取搜索参数
$minPrice = $_GET['min'];
$maxPrice = $_GET['max'];
$fuel_type = $_GET['fuel_type'];
//$minPrice = 0;
//$maxPrice = 5;
//$fuel_type = "Fish Fingers";
echo "$minPrice";
echo "$maxPrice";

echo "$fuel_type";


// 检查连接是否成功
//if (!$conn) {
//    die("连接失败: " . mysqli_connect_error());
//}
//echo "连接成功";
// 使用查询条件查询数据库


$jsonData = file_get_contents('cars.json');

// 将 JSON 数据转换为 PHP 数组
$cars = json_decode($jsonData, true);

// 筛选数据
$filteredCars = array();

foreach ($cars['cars'] as $car) {
    // 检查价格是否在指定的范围内
    if ($car['price_per_day'] >= $minPrice && $car['price_per_day'] <= $maxPrice) {
        // 检查燃料类型是否匹配
        if (strcasecmp($car['fuel_type'], $fuel_type) == 0) {
            $filteredCars[] = $car;
        }
    }
}
$cars_array = array('cars' => $filteredCars);
// 输出筛选结果
foreach ($filteredCars as $car) {
    echo $car['brand'] . ' ' . $car['model'] . ' (' . $car['year'] . ') - ' . $car['price_per_day'] . ' per day';
}
//
//echo "----------------------------------------------------------------";
//print_r($cars_array, is_array($cars_array));
//
//echo "----------------------------------------------------------------1";
//print_r($cars_array) ;


require './index.php';
?>


