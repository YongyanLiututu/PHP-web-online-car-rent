
<!DOCTYPE html>
<html>
<head>
    <title>Car Rental System</title>
    <link rel="stylesheet" href="style.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    <!-- 引入自定义的 JavaScript 文件 -->
    <!--    <script src="search.js"></script>-->
    <!--    <script src="script.js"></script>-->

</head>
<body>
<li><a href="#" id="searchBtn" onclick="function jumpToCartPage2() {
    window.location.href = 'list_carrt.php';
  }
  jumpToCartPage2()">Home</a></li>
</body>
<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');

session_start();

function customErrorHandler($errno, $errstr, $errfile, $errline) {
    // 处理错误信息
}

set_error_handler('customErrorHandler');
// 检查是否有提交的表单数据

// 更新购物车中的租赁天数
foreach ($_SESSION['cart'] as &$itemextracted) {
    $id = $itemextracted['id'];
    $daysrentedday = 0;
    if ($daysrentedday > 0) {
        $itemextracted['days'] = $daysrentedday;
    } else {
        $itemextracted['days'] = 1;
    }
}


// 检查是否有要从购物车中删除的项目
if (isset($_POST['remove'])) {
    // 从购物车中删除选定的项目
    $id = intval($_POST['remove']);
    unset($_SESSION['cart'][$id]);
}

?>
<!---->
<!--<div>================================================================</div>-->
<?php
if (!empty($_SESSION['cart'])) {
    // 计算购物车中所有项目的总价格
    $total_price = 0;
    foreach ($_SESSION['cart'] as $itemextracted) {
        $total_price += $itemextracted['price'] * $itemextracted['days'];
    }


    // 输出购物车表单

    echo '<input type="hidden" name="session_id" value="' . session_id() . '">';
    ?>

    <?php

    echo '<table>';
    ?>
    <?php
    echo '<tr><th>Car Info</th><th>Price/Day</th><th>Rental Days</th><th>Subtotal</th><th>Actions</th></tr>';
    foreach ($_SESSION['cart'] as $itemextracted) {
        // 计算每个项目的小计
        $subtotal = $itemextracted['price'] * $itemextracted['days'];
        // 输出每个项目的信息和操作
        echo '<tr>';
        echo '<td>' . $itemextracted['brand'] . ' ' . $itemextracted['model'] . ' (' . $itemextracted['year'] . ')</td>';
        echo '<td>$' . $itemextracted['price'] . '</td>';
        echo '<td><input type="number" name="days-' . $itemextracted['id'] . '" value="' . $itemextracted['days'] . '" min="1"></td>';
        echo '<td>$' . $subtotal . '</td>';
        echo '<td><a href="remove_from_cart.php?itemId=' . $itemextracted['id'] . '">Remove</a></td>';
        echo '</tr>';
    }

    // 输出购物车总价和更新按钮  <button type="submit">Empty the cart</button>
    echo '<tr><td colspan="3"><strong>Total:</strong></td><td><strong>$' . $total_price . '</strong></td>
<td><button  name="checkout" onclick="checkout1()">checkout</button></td></tr>';
    echo '</table>';

} else {
    // 如果购物车为空，则显示一个消息
    echo '<p>Your shopping cart is empty.</p>';
}
echo '<script>
function checkout1() {
    // 检查购物车是否为空
    if (' . count($_SESSION['cart']) . ' == 0) {
        alert("No car has been reserved.");
        window.location.href = "index.php";
        return;
    }
    // 获取所有“租赁天数”输入字段
    var daysFields = document.querySelectorAll(\'input[name^="days-"]\');
    // 验证每个“租赁天数”输入字段的值
    for (var i = 0; i < daysFields.length; i++) {
        var days = parseInt(daysFields[i].value);
        if (isNaN(days) || days <= 0) {
            alert("Rental days must be an integer greater than zero.");
            daysFields[i].focus();
            return;
        }
    }
    // 跳转到结算页面
    window.location.href = "checkout.php";
}

</script>';
echo '<script>
function checkout1() {
    // 检查购物车是否为空
    if (' . count($_SESSION['cart']) . ' == 0) {
        alert("No car has been reserved.");
        window.location.href = "index.php";
        return;
    }
    // 获取所有“租赁天数”输入字段
    var daysFields = document.querySelectorAll(\'input[name^="days-"]\');
    // 验证每个“租赁天数”输入字段的值
    for (var i = 0; i < daysFields.length; i++) {
        var days = parseInt(daysFields[i].value);
        if (isNaN(days) || days <= 0) {
            alert("Rental days must be an integer greater than zero.");
            daysFields[i].focus();
            return;
        }
    }
    // 跳转到结算页面
    window.location.href = "emailaddress.php";
//    window.location.href = "checkout.php";
}

</script>';
?>

<script>
    function removeFromCart(itemId) {
        // 构造请求
        var request = new XMLHttpRequest();
        request.open('POST', 'remove_from_cart.php', true);
        request.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8');

        // 处理响应
        request.onload = function() {
            if (request.status >= 200 && request.status < 400) {
                // 从购物车表格中删除对应的行
                var rowToRemove = document.getElementById('item-' + itemId);
                rowToRemove.parentNode.removeChild(rowToRemove);
            }
        };

        // 发送请求
        request.send('itemId=' + encodeURIComponent(itemId));
    }

    function checkout1() {
        // 检查购物车是否为空
        if (<?php echo count($_SESSION['cart']); ?> == 0) {
            alert("No car has been reserved.");
            window.location.href = "index.php";
            return;
        }
        // 获取所有“租赁天数”输入字段
        var daysFields = document.querySelectorAll('input[name^="days-"]');
        // 验证每个“租赁天数”输入字段的值
        for (var i = 0; i < daysFields.length; i++) {
            var days = parseInt(daysFields[i].value);
            if (isNaN(days) || days <= 0) {
                alert("Rental days must be an integer greater than zero.");
                daysFields[i].focus();
                return;
            }
        }
        // 跳转到结算页面
        window.location.href = "emailaddress.php";
        // window.location.href = "checkout.php";
    }

    function validateDays(field) {
        var days = parseInt(field.value);
        if (isNaN(days) || days <= 0) {
            alert("Rental days must be an integer greater than zero.");
            field.focus();
        }
    }
    </scrip>