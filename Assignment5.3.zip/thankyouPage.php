
<script>
    var successMessage = 'Order successfully placed!';
    alert(successMessage);
</script>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="style(3)(1).css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <title  class="title">The email has been sent successfully. Please check your mailbox</title>

</head>
<body>
<header class="header">
    <div class="logo">
        <img src="logo.png" alt="Logo">
    </div>
    <div class="header1">
        <h1 class="logo">UTS Car Rental Store</h1>
    </div>
    <ul class="ul1">
<!--        <li><a href="#" id="searchBtn">Search</a></li>-->
        <li><a href="./list_carrt.php" >Home</a></li>
<!--        <li><a href="#" id="cartBtn">Cart</a></li>-->
    </ul>

</header>
<h1 class="thankpage-h1">The email has been sent successfully. Please check your mailbox!!!</h1>
<p>Your order details have been sent to your email address.</p>
<!--<p>Your order details have been sent to your email address.</p>-->
<button onclick="location.href='./list_carrt.php'">Return to main page</button>
</body>
</html>
