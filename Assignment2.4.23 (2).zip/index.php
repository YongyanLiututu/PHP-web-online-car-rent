<!DOCTYPE html>
<html>
<head>
    <title>Car Rental System</title>
    <link rel="stylesheet" href="style.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- 引入自定义的 JavaScript 文件 -->
<!--    <script src="search.js"></script>-->
    <!--    <script src="script.js"></script>-->

</head>
<body>
<!--头部文件-->
<header class="header">
    <div class="logo">
        <img src="logo.png" alt="Logo">
    </div>
    <div class="header1">
        <h1>Hertz-UTS</h1>
    </div>
    <ul class="ul1">
        <li><a href="#" id="searchBtn">Search</a></li>
        <li><a href="./list_item.php" id="searchBtn">Home</a></li>
        <li><a href="#" id="cartBtn">Cart</a></li>
    </ul>
</header>
<boby>
<!--    主体-->
    <div class="main-content" id="mainContent">
        <div id="content">
           
                    <div id="<?php echo $itemID; ?>" class="goods-box">
                        <img src="./photo/<?php echo $item['photo']; ?>.png" alt="Item 1"  onclick="details('<?php echo "/photo/".$item['photo']; ?>', '<?php echo $item['product_name']; ?>', '<?php echo $item['unit_price']; ?>', '<?php echo $item['unit_quantity']; ?>', '<?php echo $item['in_stock']; ?>', '<?php echo $item['description']; ?>', this.nextElementSibling)">

                        <p1 class="goods-name" onclick="details('<?php echo "/photo/".$item['photo']; ?>', '<?php echo $item['product_name']; ?>', '<?php echo $item['unit_price']; ?>', '<?php echo $item['unit_quantity']; ?>', '<?php echo $item['in_stock']; ?>', '<?php echo $item['description']; ?>',document.getElementById('quantity-Input'))"> <?php echo $item['product_name']; ?>
                        </p1>

                        <p class="goods-price">Price: <?php echo $item['unit_price']; ?>
                        </p>
                        <p class="goods-quantity">Quantity: <?php echo $item['unit_quantity']; ?>
                        </p>
                        <p class="goods-in_stock">In_stock: <?php echo $item['in_stock']; ?>
                        </p>

                        <p class="goods-detail">Description: <?php echo $item['description']; ?>
                        </p>
                        <button class="quantity-btn" onclick="decreaseQuantity('<?php echo $item['product_id']; ?>')">
                            -
                        </button>
                        <input type="number" min="1" max="99" class="quantity-input" value="1"
                               id="quantity-<?php echo $item['product_id']; ?>" required>
                        <button class="quantity-btn" onclick="increaseQuantity('<?php echo $item['product_id']; ?>')">
                            +
                        </button>
                        <button class="addcart"
                                onclick="update('<?php echo $item['unit_price']; ?>', document.querySelector('#quantity-<?php echo $item['product_id']; ?>').value, '<?php echo $item['product_name']; ?>', 'type')">
                            Add to cart
                        </button>
                    </div>
                   
                <div class="no-goods-box">
                  
                </div>
            <div class="main-content" id="mainContent">
                <div id="content">

                    <div id="<?php echo $itemID; ?>" class="goods-box">
                        <img src="./photo/<?php echo $item['photo']; ?>.png" alt="Item 1"  onclick="details('<?php echo "/photo/".$item['photo']; ?>', '<?php echo $item['product_name']; ?>', '<?php echo $item['unit_price']; ?>', '<?php echo $item['unit_quantity']; ?>', '<?php echo $item['in_stock']; ?>', '<?php echo $item['description']; ?>', this.nextElementSibling)">

                        <p1 class="goods-name" onclick="details('<?php echo "/photo/".$item['photo']; ?>', '<?php echo $item['product_name']; ?>', '<?php echo $item['unit_price']; ?>', '<?php echo $item['unit_quantity']; ?>', '<?php echo $item['in_stock']; ?>', '<?php echo $item['description']; ?>',document.getElementById('quantity-Input'))"> <?php echo $item['product_name']; ?>
                        </p1>

                        <p class="goods-price">Price: <?php echo $item['unit_price']; ?>
                        </p>
                        <p class="goods-quantity">Quantity: <?php echo $item['unit_quantity']; ?>
                        </p>
                        <p class="goods-in_stock">In_stock: <?php echo $item['in_stock']; ?>
                        </p>

                        <p class="goods-detail">Description: <?php echo $item['description']; ?>
                        </p>
                        <button class="quantity-btn" onclick="decreaseQuantity('<?php echo $item['product_id']; ?>')">
                            -
                        </button>
                        <input type="number" min="1" max="99" class="quantity-input" value="1"
                               id="quantity-<?php echo $item['product_id']; ?>" required>
                        <button class="quantity-btn" onclick="increaseQuantity('<?php echo $item['product_id']; ?>')">
                            +
                        </button>
                        <button class="addcart"
                                onclick="update('<?php echo $item['unit_price']; ?>', document.querySelector('#quantity-<?php echo $item['product_id']; ?>').value, '<?php echo $item['product_name']; ?>', 'type')">
                            Add to cart
                        </button>
                    </div>

                    <div class="no-goods-box">

                    </div>
                    <div class="main-content" id="mainContent">
                        <div id="content">

                            <div id="<?php echo $itemID; ?>" class="goods-box">
                                <img src="./photo/<?php echo $item['photo']; ?>.png" alt="Item 1"  onclick="details('<?php echo "/photo/".$item['photo']; ?>', '<?php echo $item['product_name']; ?>', '<?php echo $item['unit_price']; ?>', '<?php echo $item['unit_quantity']; ?>', '<?php echo $item['in_stock']; ?>', '<?php echo $item['description']; ?>', this.nextElementSibling)">

                                <p1 class="goods-name" onclick="details('<?php echo "/photo/".$item['photo']; ?>', '<?php echo $item['product_name']; ?>', '<?php echo $item['unit_price']; ?>', '<?php echo $item['unit_quantity']; ?>', '<?php echo $item['in_stock']; ?>', '<?php echo $item['description']; ?>',document.getElementById('quantity-Input'))"> <?php echo $item['product_name']; ?>
                                </p1>

                                <p class="goods-price">Price: <?php echo $item['unit_price']; ?>
                                </p>
                                <p class="goods-quantity">Quantity: <?php echo $item['unit_quantity']; ?>
                                </p>
                                <p class="goods-in_stock">In_stock: <?php echo $item['in_stock']; ?>
                                </p>

                                <p class="goods-detail">Description: <?php echo $item['description']; ?>
                                </p>
                                <button class="quantity-btn" onclick="decreaseQuantity('<?php echo $item['product_id']; ?>')">
                                    -
                                </button>
                                <input type="number" min="1" max="99" class="quantity-input" value="1"
                                       id="quantity-<?php echo $item['product_id']; ?>" required>
                                <button class="quantity-btn" onclick="increaseQuantity('<?php echo $item['product_id']; ?>')">
                                    +
                                </button>
                                <button class="addcart"
                                        onclick="update('<?php echo $item['unit_price']; ?>', document.querySelector('#quantity-<?php echo $item['product_id']; ?>').value, '<?php echo $item['product_name']; ?>', 'type')">
                                    Add to cart
                                </button>
                            </div>

                            <div class="no-goods-box">

                            </div>
                            <div class="main-content" id="mainContent">
                                <div id="content">

                                    <div id="<?php echo $itemID; ?>" class="goods-box">
                                        <img src="./photo/<?php echo $item['photo']; ?>.png" alt="Item 1"  onclick="details('<?php echo "/photo/".$item['photo']; ?>', '<?php echo $item['product_name']; ?>', '<?php echo $item['unit_price']; ?>', '<?php echo $item['unit_quantity']; ?>', '<?php echo $item['in_stock']; ?>', '<?php echo $item['description']; ?>', this.nextElementSibling)">

                                        <p1 class="goods-name" onclick="details('<?php echo "/photo/".$item['photo']; ?>', '<?php echo $item['product_name']; ?>', '<?php echo $item['unit_price']; ?>', '<?php echo $item['unit_quantity']; ?>', '<?php echo $item['in_stock']; ?>', '<?php echo $item['description']; ?>',document.getElementById('quantity-Input'))"> <?php echo $item['product_name']; ?>
                                        </p1>

                                        <p class="goods-price">Price: <?php echo $item['unit_price']; ?>
                                        </p>
                                        <p class="goods-quantity">Quantity: <?php echo $item['unit_quantity']; ?>
                                        </p>
                                        <p class="goods-in_stock">In_stock: <?php echo $item['in_stock']; ?>
                                        </p>

                                        <p class="goods-detail">Description: <?php echo $item['description']; ?>
                                        </p>
                                        <button class="quantity-btn" onclick="decreaseQuantity('<?php echo $item['product_id']; ?>')">
                                            -
                                        </button>
                                        <input type="number" min="1" max="99" class="quantity-input" value="1"
                                               id="quantity-<?php echo $item['product_id']; ?>" required>
                                        <button class="quantity-btn" onclick="increaseQuantity('<?php echo $item['product_id']; ?>')">
                                            +
                                        </button>
                                        <button class="addcart"
                                                onclick="update('<?php echo $item['unit_price']; ?>', document.querySelector('#quantity-<?php echo $item['product_id']; ?>').value, '<?php echo $item['product_name']; ?>', 'type')">
                                            Add to cart
                                        </button>
                                    </div>

                                    <div class="no-goods-box">

                                    </div>
                
        </div>
        <!-- 显示购物车内容的 HTML 元素 -->
        <!--        <button onclick="update1()"> test</button>-->
        <p class="goods-price" id="cart-content1"></p>
    </div>
    </div>



</boby>
</body>
</html>


