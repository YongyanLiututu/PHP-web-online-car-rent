<!DOCTYPE html>
<html>
<head>
    <title>Car Rental System</title>
    <link rel="stylesheet" href="style.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- 引入自定义的 JavaScript 文件 -->
<!--    <script src="search.js"></script>-->
    <!--    <script src="script.js"></script>-->

</head>
<body>
<!--头部文件-->
<header class="header">
    <div class="logo">
        <img src="logo.png" alt="Logo">
    </div>
    <div class="header1">
        <h1>Hertz-UTS</h1>
    </div>
    <ul class="ul1">
        <li><a href="#" id="searchBtn">Search</a></li>
        <li><a href="./list_item.php" id="searchBtn">Home</a></li>
        <li><a href="#" id="cartBtn">Cart</a></li>
    </ul>
</header>
</body>
</html>


